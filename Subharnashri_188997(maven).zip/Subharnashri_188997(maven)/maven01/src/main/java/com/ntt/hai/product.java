package com.ntt.hai;

public class product {
private int productid;
private String productname;
public int getProductid() {
	return productid;
}
public void setProductid(int productid) {
	this.productid = productid;
}
public String getProductname() {
	return productname;
}
public void setProductname(String productname) {
	this.productname = productname;
}
public void printdata()
{
System.out.println("your data printed");	
}

}
